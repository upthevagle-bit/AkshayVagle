# MAN-VIS Premium DJ Booking Website

Static, Vercel-ready artist booking website for DJ MAN-VIS.

Live production URL currently used in metadata:

```txt
https://bookmanvis.vercel.app/
```

## Artist Positioning

- Main genre: Afro House
- Secondary genres: Melodic House & Techno, Progressive House, Melodic Techno, and Electronic Dance Music
- Event focus: weddings, engagements, club nights, rooftop events, music festivals, live gigs, private parties, corporate events, and cultural celebrations

## Files

- `index.html` - full website markup and SEO/social tags.
- `style.css` - premium responsive nightlife styling.
- `script.js` - smooth scrolling, reveal animation, validation, and Formspree submission.
- `assets/images/` - real uploaded MAN-VIS artist images used across the site.
- `assets/favicon.svg` - browser tab icon.
- `assets/manvis-logo.svg` - MAN-VIS logo asset used in the header, hero card, and booking profile card.

## Uploaded Images Used

- `assets/images/manvis-silent-session.jpg`
- `assets/images/manvis-festival-gig.jpg`
- `assets/images/manvis-dj-selfie-33west.jpg`
- `assets/images/manvis-33west-club-night.jpg`
- `assets/images/manvis-club-night.jpg`
- `assets/images/manvis-portrait-decks.jpg`

No stock images or placeholder images are used in the website experience.

## Formspree

The booking form sends to:

```js
const FORMSPREE_ENDPOINT = "https://formspree.io/f/maqkplaq";
```

To change it later, update only the `FORMSPREE_ENDPOINT` value in `script.js`.

## WhatsApp

Primary booking link:

```txt
https://wa.me/9779768377067?text=Hi%20MAN-VIS,%20I%E2%80%99d%20like%20to%20enquire%20about%20booking%20you%20for%20an%20event.
```

The site includes WhatsApp in the hero, booking profile card, footer, floating desktop button, and sticky mobile booking bar.

## Instagram

Instagram link:

```txt
https://www.instagram.com/manvis_official?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==
```

Instagram is used in the header, hero, nightlife CTA, social follow section, and footer.

## Deploy on Vercel

1. Push this folder to a GitHub repository.
2. Import the repository in Vercel.
3. Use the static/default project settings.
4. Leave build command empty.
5. Leave output directory empty or set it to `.`.
6. Deploy.

After deploying to a new domain, update the canonical, Open Graph, and Twitter image URLs in `index.html`.
